
READ ME
th_saturn_vol1 (Exploring Saturn, Vol. 1)
------------------------------------------------------------
By rthorvald


Installation
------------------------------------------------------------
To install in Celestia,just unzip to your 'extras' folder,
alternately to your 'addons' folder inside 'extras'.


Compability:
------------------------------------------------------------
Created and tested for Celestia 1.4.1 and 1.4.2.


Copyright:
------------------------------------------------------------
All contents are the work of Runar Thorvaldsen (rthorvald),
exept for:

- t00fri_gh_saturnrings.png by dr. Fridger Schremmp and
  Grant Hutchinson. Used here with permission from both
  parties.

You have permission to use this work for any non-commercial
purpose. Re-distribution is allowed as long as you do not
charge money for neither the package itself nor access to it.

Copyright� Runar Thorvaldsen, May 22, 2006.
Released under the Creative Commons Licence
Attribution-NonCommercial-ShareAlike 2.5
Please see http://creativecommons.org/licenses/by-nc-sa/2.5/
for details.
------------------------------------------------------------

Sources:
- Bjorn Johanssons Voyager Saturn map
- CICLOPS Cassini imagery


------------------------------------------------------------
Runar Thorvaldsen, 03. november 2006
Contact: rthorvald@celestialmatters.org
http://www.celestialmatters.org



